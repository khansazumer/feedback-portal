// SAFE VERSION -- same features, hardened.
const express = require('express');
const mysql = require('mysql2');
const cookieSession = require('cookie-session');
const escapeHtml = require('escape-html');
const csrf = require('csurf');
const path = require('path');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// FIX (CSRF defense, part 1): SameSite=Strict cookie
app.use(cookieSession({
  name: 'session',
  keys: ['use-a-real-secret-in-prod'],
  sameSite: 'strict',
  httpOnly: true,
}));

// FIX (CSRF defense, part 2): token-based protection on state-changing routes
const csrfProtection = csrf({ cookie: false });

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'abcd',
  database: 'feedback_portal'
});

// ---------- 1. SQLi EASY fix: parameterized query ----------
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  // FIX: placeholders, driver escapes values -- ' OR '1'='1 no longer works
  db.query(
    'SELECT * FROM users WHERE username = ? AND password = ?',
    [username, password],
    (err, results) => {
      if (err) return res.status(500).send('Something went wrong.'); // FIX: no raw DB error leaked
      if (results.length > 0) {
        req.session.user = results[0].username;
        req.session.userId = results[0].id;
        return res.send(`Logged in as ${escapeHtml(results[0].username)}. <a href="/dashboard">Dashboard</a>`);
      }
      res.send('Invalid credentials');
    }
  );
});

// ---------- 2. SQLi INTERMEDIATE fix: validate + parameterize ----------
app.get('/profile', (req, res) => {
  const rawId = req.query.id;
  if (!/^\d+$/.test(rawId)) return res.status(400).send('Invalid id'); // FIX: strict type check
  const id = parseInt(rawId, 10);
  db.query('SELECT username, email FROM users WHERE id = ?', [id], (err, results) => {
    if (err) return res.status(500).send('Something went wrong.');
    if (results.length > 0) res.send(`User found: ${escapeHtml(results[0].username)}`);
    else res.send('No such user');
  });
});

// ---------- 3. SQLi ADVANCED fix: parameterized, no UNION possible ----------
app.get('/search-user', (req, res) => {
  const name = req.query.name || '';
  db.query(
    "SELECT username, email, 'review' AS type FROM users WHERE username = ?",
    [name],
    (err, results) => {
      if (err) return res.status(500).send('Something went wrong.');
      res.json(results);
    }
  );
});

// ---------- 4. Reflected XSS fix: output-encode user input ----------
app.get('/search', (req, res) => {
  const q = req.query.q || '';
  res.send(`
    <h2>Search results for: ${escapeHtml(q)}</h2>
    <p>No reviews matched your search.</p>
    <a href="/">Home</a>
  `);
});

// ---------- 5. Stored XSS fix: encode on output ----------
app.post('/review', csrfProtection, (req, res) => {
  const { course, comment, userId } = req.body;
  db.query(
    'INSERT INTO reviews (user_id, course, comment) VALUES (?, ?, ?)',
    [userId, course, comment], // raw store is fine; the fix is on OUTPUT below
    (err) => {
      if (err) return res.status(500).send('Something went wrong.');
      res.redirect('/reviews.html');
    }
  );
});

app.get('/api/reviews', (req, res) => {
  db.query('SELECT course, comment FROM reviews', (err, results) => {
    if (err) return res.status(500).send('Something went wrong.');
    // FIX: escape before sending so the client can safely use textContent/innerHTML
    const safe = results.map(r => ({
      course: escapeHtml(r.course),
      comment: escapeHtml(r.comment)
    }));
    res.json(safe);
  });
});

// CSRF token endpoint so the frontend can fetch a token before posting
app.get('/csrf-token', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

// ---------- 6. CSRF fix: token required ----------
app.post('/change-email', csrfProtection, (req, res) => {
  if (!req.session.userId) return res.status(401).send('Not logged in');
  const { newEmail } = req.body;
  db.query('UPDATE users SET email = ? WHERE id = ?', [newEmail, req.session.userId], (err) => {
    if (err) return res.status(500).send('Something went wrong.');
    res.send('Email updated to ' + escapeHtml(newEmail));
  });
});

app.listen(3001, () => console.log('SAFE app running on http://localhost:3001'));
