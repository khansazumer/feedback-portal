CREATE DATABASE IF NOT EXISTS feedback_portal;
USE feedback_portal;

DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,   -- plaintext here ONLY to keep SQLi demo simple; mention in report this is intentionally weak for the lab, not real practice
  email VARCHAR(100) NOT NULL
);

CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  course VARCHAR(100) NOT NULL,
  comment TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- seed data
INSERT INTO users (username, password, email) VALUES
  ('alice', 'alice123', 'alice@example.com'),
  ('bob', 'bobpass', 'bob@example.com'),
  ('admin', 'SuperSecretAdminPass!', 'admin@example.com');

INSERT INTO reviews (user_id, course, comment) VALUES
  (1, 'Information Security', 'Great course, learned a lot!'),
  (2, 'Databases', 'Assignments were tough but fair.');
