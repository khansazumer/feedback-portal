// VULNERABLE VERSION -- for academic demonstration only.
// Deliberately contains: Reflected XSS, Stored XSS, DOM XSS (client-side),
// CSRF (no token), SQLi (string concatenation).

const express = require('express');
const mysql = require('mysql2');
const cookieSession = require('cookie-session');
const path = require('path');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Cookie with NO SameSite restriction -> CSRF possible
app.use(cookieSession({
  name: 'session',
  keys: ['insecure-demo-key'],
  // no sameSite set -> defaults are attacker-friendly for this demo
}));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'abcd',
  database: 'feedback_portal'
});

// ---------- 1. SQLi EASY: login via string concatenation ----------
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
  // VULNERABLE: payload like  ' OR '1'='1' --  bypasses auth
  db.query(query, (err, results) => {
    if (err) return res.status(500).send('DB error: ' + err.message); // also leaks query errors (error-based SQLi aid)
    if (results.length > 0) {
      req.session.user = results[0].username;
      req.session.userId = results[0].id;
      return res.send(`Logged in as ${results[0].username}. <a href="/dashboard">Dashboard</a>`);
    }
    res.send('Invalid credentials');
  });
});

// ---------- 2. SQLi INTERMEDIATE: boolean-based blind via id ----------
app.get('/profile', (req, res) => {
  const id = req.query.id; // not validated/parameterized
  const query = `SELECT username, email FROM users WHERE id = ${id}`;
  // VULNERABLE: ?id=1 AND 1=1  vs  ?id=1 AND 1=2  -> different page content
  db.query(query, (err, results) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    if (results.length > 0) res.send(`User found: ${results[0].username}`);
    else res.send('No such user');
  });
});

// ---------- 3. SQLi ADVANCED: UNION-based via search-user ----------
app.get('/search-user', (req, res) => {
  const name = req.query.name || '';
  const query = `SELECT username, email, 'review' FROM users WHERE username = '${name}'`;
  // VULNERABLE: supports UNION SELECT chain -> columns -> tables -> data
  db.query(query, (err, results) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    res.json(results);
  });
});

// ---------- 4. Reflected XSS ----------
app.get('/search', (req, res) => {
  const q = req.query.q || '';
  // VULNERABLE: q is echoed back with no encoding
  res.send(`
    <h2>Search results for: ${q}</h2>
    <p>No reviews matched your search.</p>
    <a href="/">Home</a>
  `);
});

// ---------- 5. Stored XSS ----------
app.post('/review', (req, res) => {
  const { course, comment, userId } = req.body;
  // VULNERABLE: comment stored raw, no sanitization
  db.query(
    'INSERT INTO reviews (user_id, course, comment) VALUES (?, ?, ?)',
    [userId, course, comment],
    (err) => {
      if (err) return res.status(500).send('DB error: ' + err.message);
      res.redirect('/reviews.html');
    }
  );
});

app.get('/api/reviews', (req, res) => {
  db.query('SELECT course, comment FROM reviews', (err, results) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    // VULNERABLE: comment sent as raw HTML string for the client to innerHTML
    res.json(results);
  });
});

// ---------- 6. CSRF: change email, cookie-only auth, no token ----------
app.post('/change-email', (req, res) => {
  if (!req.session.userId) return res.status(401).send('Not logged in');
  const { newEmail } = req.body;
  // VULNERABLE: no CSRF token check, relies only on session cookie
  db.query('UPDATE users SET email = ? WHERE id = ?', [newEmail, req.session.userId], (err) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    res.send('Email updated to ' + newEmail);
  });
});

app.listen(3000, () => console.log('VULNERABLE app running on http://localhost:3000'));
